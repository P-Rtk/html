<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>






    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/sweatshirts/sw9.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Solid High Neck Casual Men Yellow Sweater</h5>
                         <p class="card-text">Price : Rs.849</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Solid High Neck Casual Men Yellow Sweater">
                          <input type="hidden" name="Price" value="849">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/sweatshirts/sw2.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Full Sleeve Color Block Men Sweatshirt</h5>
                         <p class="card-text">Price : Rs.999</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Full Sleeve Color Block Men Sweatshirt">
                          <input type="hidden" name="Price" value="999">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/sweatshirts/sw14.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Full Sleeve Solid Men Sweatshirt</h5>
                         <p class="card-text">Price : Rs.1749</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Full Sleeve Solid Men Sweatshirt">
                          <input type="hidden" name="Price" value="1749">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/sweatshirts/sw11.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Full Sleeve Solid Men Sweatshirt</h5>
                         <p class="card-text">Price : Rs.838</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Full Sleeve Solid Men Sweatshirt">
                          <input type="hidden" name="Price" value="838">
                    </div>
                </div>
                </form>
    		</div>
</div>
</div> <br><br>

 <div class="container mt-4">
      <div class="row">

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/sweatshirts/sw18.jpeg" class="card-img-top"><br><BR>
                     <div class="card-body text-center">
                      <h5 class="card-title">Self Design Turtle Neck Casual Men Blue Sweater</h5>
                         <p class="card-text">Price : Rs.1599</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Self Design Turtle Neck Casual Men Blue Sweater">
                          <input type="hidden" name="Price" value="1599">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/sweatshirts/sw6.jpeg" class="card-img-top"><br><BR>
                     <div class="card-body text-center">
                      <h5 class="card-title">Woven Round Neck Casual Reversible Black Sweater</h5>
                         <p class="card-text">Price : Rs.1390</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Woven Round Neck Casual Reversible Black Sweater">
                          <input type="hidden" name="Price" value="1390">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/sweatshirts/sw7.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Striped Round Neck Casual Men Grey Sweater</h5>
                         <p class="card-text">Price : Rs.949</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Striped Round Neck Casual Men Grey Sweater">
                          <input type="hidden" name="Price" value="949">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/sweatshirts/sw16.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Self Design Turtle Neck Casual Men Black Sweater</h5>
                         <p class="card-text">Price : Rs.1049</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Self Design Turtle Neck Casual Men Black Sweater">
                          <input type="hidden" name="Price" value="1049">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div><br><br><br>
</body>
</html>