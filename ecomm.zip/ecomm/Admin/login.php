<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE-edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin Login</title>
	<link rel="stylesheet" type="text/css" href="logincss.css">
</head>
<body>

	<div class="container">
		<div class="myform">
			<form>
				<h2>ADMIN LOGIN</h2>
				<input type="text" placeholder="Admin Name">
				<input type="text" placeholder="Password">
				<button type="submit">LOGIN</button>
			</form>
		</div>
		<div class="image">
			<img src="contact1.jfif" width="300px">
		</div>
	</div>

</body>
</html>