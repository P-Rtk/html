<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>






    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/tops/t1.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Casual Juliet Sleeve Solid Women Black Top</h5>
                         <p class="card-text">Price : Rs.540</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Casual Juliet Sleeve Solid Women Black Top">
                          <input type="hidden" name="Price" value="540">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/tops/t2.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Casual Bell Sleeve Solid Women Green Top</h5>
                         <p class="card-text">Price : Rs.431</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Casual Bell Sleeve Solid Women Green Top">
                          <input type="hidden" name="Price" value="431">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/tops/t10.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Casual Full Sleeve Printed Women Grey Top</h5>
                         <p class="card-text">Price : Rs.765</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Casual Full Sleeve Printed Women Grey Top">
                          <input type="hidden" name="Price" value="765">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/tops/t9.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Casual Bishop Sleeve Solid Women Black Top</h5>
                         <p class="card-text">Price : Rs.499</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Casual Bishop Sleeve Solid Women Black Top">
                          <input type="hidden" name="Price" value="499">
                    </div>
                </div>
                </form>
    		</div>
</div>
</div> <br><br>

 <div class="container mt-4">
      <div class="row">

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/tops/t14.jpg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women's Off Shoulder <br>Net top</h5>
                         <p class="card-text">Price : Rs.592</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women's Off Shoulder Net top">
                          <input type="hidden" name="Price" value="592">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/tops/t13.jpg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women White Printed <br>Top</h5>
                         <p class="card-text">Price : Rs.899</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women White Printed Top">
                          <input type="hidden" name="Price" value="899">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/tops/t19.jpg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Pretty Partywear Tops <br> & Tunics</h5>
                         <p class="card-text">Price : Rs.789</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Pretty Partywear Tops & Tunics">
                          <input type="hidden" name="Price" value="789">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/tops/t20.jpg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Stylish Designer Women <br>Tops & Tunics</h5>
                         <p class="card-text">Price : Rs.999</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Stylish Designer Women Tops & Tunics">
                          <input type="hidden" name="Price" value="999">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div><br><br><br>
</body>
</html>