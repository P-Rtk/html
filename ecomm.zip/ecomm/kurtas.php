<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>






    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/kurtas/k6.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Solid Cotton Blend Straight Kurta (Yellow)</h5>
                         <p class="card-text">Price : Rs.475</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Solid Cotton Blend Straight Kurta (Yellow)">
                          <input type="hidden" name="Price" value="475">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/kurtas/k2.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Solid Cotton Blend Straight Kurta (White)</h5>
                         <p class="card-text">Price : Rs.529</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Solid Cotton Blend Straight Kurta (White)">
                          <input type="hidden" name="Price" value="529">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/kurtas/k10.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Solid Silk Blend Straight Kurta (Black)</h5>
                         <p class="card-text">Price : Rs.655</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Solid Silk Blend Straight Kurta (Black)">
                          <input type="hidden" name="Price" value="655">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/kurtas/k7.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Solid Cotton Blend Straight Kurta (Grey)</h5>
                         <p class="card-text">Price : Rs.549</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Solid Cotton Blend Straight Kurta (Grey)">
                          <input type="hidden" name="Price" value="549">
                    </div>
                </div>
                </form>
    		</div>
      </div>
    </div><br><br>

     <div class="container mt-4">
      <div class="row">

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/kurtas/k21.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Hangup Printed <br>Sherwani</h5>
                         <p class="card-text">Price : Rs.1200</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Hangup Printed Sherwani">
                          <input type="hidden" name="Price" value="1200">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/kurtas/k22.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">VASTRAMAY Self Design <br>Sherwani</h5>
                         <p class="card-text">Price : Rs.1690</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="VASTRAMAY Self Design Sherwani">
                          <input type="hidden" name="Price" value="1690">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/kurtas/k19.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Geometric Print Men Round Neck Blue T-Shirt</h5>
                         <p class="card-text">Price : Rs.780</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Geometric Print Men Round Neck Blue T-Shirt">
                          <input type="hidden" name="Price" value="780">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/kurtas/k23.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">VASTRAMAY Floral Print, Printed Sherwani</h5>
                         <p class="card-text">Price : Rs.1580</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="VASTRAMAY Floral Print, Printed Sherwani">
                          <input type="hidden" name="Price" value="1580">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div>
</body>
</html>