<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>jeans</title>
</head>
<body>






    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/jeans/j18.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Slim Men Brown Jeans</h5>
                         <p class="card-text">Price : Rs.588</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Slim Men Brown Jeans">
                          <input type="hidden" name="Price" value="588">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/jeans/j2.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Regular Men Blue Jeans</h5>
                         <p class="card-text">Price : Rs.584</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Regular Men Blue Jeans">
                          <input type="hidden" name="Price" value="584">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/jeans/j3.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Slim Men Black Jeans</h5>
                         <p class="card-text">Price : Rs.519</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Slim Men Black Jeans">
                          <input type="hidden" name="Price" value="519">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/jeans/j4.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Super Skinny White Jeans</h5>
                         <p class="card-text">Price : Rs.554</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Super Skinny White Jeans">
                          <input type="hidden" name="Price" value="554">
                    </div>
                </div>
                </form>
    		</div>
</div>
</div>

<br><br>
<div class="container mt-4">
      <div class="row">
    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/jeans/j5.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Slim Dark Blue Jeans</h5>
                         <p class="card-text">Price : Rs.424</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Slim Dark Blue Jeans">
                          <input type="hidden" name="Price" value="424">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/jeans/j15.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Slim Men White Jeans</h5>
                         <p class="card-text">Price : Rs.785</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Slim Men White Jeans">
                          <input type="hidden" name="Price" value="785">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/jeans/j13.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Jogger Fit Men Brown Jeans</h5>
                         <p class="card-text">Price : Rs.899</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Jogger Fit Men Brown Jeans">
                          <input type="hidden" name="Price" value="899">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/jeans/j8.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Slim Men Grey Jeans</h5>
                         <p class="card-text">Price : Rs.779</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Slim Men Grey Jeans">
                          <input type="hidden" name="Price" value="779">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div><br><br><br>
</body>
</html>