<?php
session_start();
?>
<HTML>
<HEAD>
	<TITLE>Supermarket</TITLE>
	<META NAME="Generator" CONTENT="Editplus">
	<META NAME="Author" CONTENT=" ">
	<META NAME="Keywords" CONTENT=" ">
	<META NAME="Discription" CONTENT=" ">
    <link rel="stylesheet" href="css/homecss.css"/>
        <link rel="stylesheet" href="K:\fontawesome\fontawesome-free-5.13.0-web\fontawesome-
    fontawesome-free-5.13.0-web\css\all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,600;1,600&display=swap" rel="stylesheet">
        <script>
    	function stickyMenu(){
    		var sticky=document.getElementById('sticky');
    		if (window.pageYOFFset > 220) {
    			sticky.classList.add('sticky');
    		}
    		else{
    			sticky.classList.remove('sticky');
    		}
    	}
    window.onscroll=function() {
    	stickyMenu();
    }
    </script>

</HEAD>
<BODY>
		<div class="parallax" style="background-image:url('img/back.jpg')">
		<div class="page-title">Trends Partner</div>
	</div>
	<div class="menu" id="sticky">
   <ul class="menu-ul">
        	<a href="home.php" class="a-menu"><li>Home</li></a>
            <!-- <a href="aboutus.php" class="a-menu"><li>About Us</li></a> -->
            <a href="contactus.php" class="a-menu"><li>Contact Us</li></a>
            <a href="categorymain.php" class="a-menu"><li>Catergories</li></a>

            <?php 
              
              $count=0;
              if(isset($_SESSION['cart']))
              {
                $count=count($_SESSION['cart']);
              }

            ?>
            <a href="mycart.php" class="a-menu"><li>My Cart (<?php echo $count;  ?>)</li></a>
            <!-- <a href="loginpage.php" class="a-menu"><li>Login</li></a> -->
        </ul>
                <div class="search-box">
       <!-- 	<form>
        		<input type="text" placeholder="Search..." name="search" class="search-input"/>
        	    <button type="submit"><i class="fa fa-search"></i></button>
        	</form>-->
        </div>
    </div>
    <!--Home Page Begins-->
          <div class="container">
          	 <a href="#Vegetables">
          	 	<div class="categories">
          	 		<img src="img\veg.jpg" class="item-image"/>
          	 		<div class="image-title">Vegetables</div>
          	 	</div>
          	</a>
          	<a href="#Fruits">
          	 	<div class="categories">
          	 		<img src="img\fas.jpg" class="item-image"/>
          	 		<div class="image-title">Fashion</div>
          	 	</div>
          	</a>
          	<a href="#Meat">
          	 	<div class="categories">
          	 		<img src="img\dev.jpg" class="item-image"/>
          	 		<div class="image-title">Appliances</div>
          	 	</div>
          	</a>
          	<a href="#Deals">
          	 	<div class="categories">
          	 		<img src="img\shoes.jpg" class="item-image"/>
          	 		<div class="image-title">Shoes</div>
          	 	</div>
          	</a>
          </div>
          <!--Deal Begins Here-->
    	  <div class="deals-container" id="deals">
    	  	<div class="parallax">
    	  		<div class="title">DEALS</div>
    	  	</div>
    	  	<div class="deal">
    	  		Save 20% on min-purchase of $149 on vegetable<br/>
    	  		<button class="coupon-btn">Add Coupon</button>
    	  	</div>
    	  	<div class="deal">
    	  		Save 10% on min-purchase of $179 on shoes<br/>
    	  		<button class="coupon-btn">Add Coupon</button>
    	  	</div>
    	  	<div class="deal">
    	  		Save 15% on min-purchase of $199 on Fasion outfits<br/>
    	  		<button class="coupon-btn">Add Coupon</button>
    	  	</div>

    	  </div>
    <!--Deal Ends Here-->
    <!--Veg Begins Here-->
       <div class="deals-container" id="vegetables">
           <div class="parallax">
               <div class="title">VEGETABLES</div>
            </div>
            
            <div class="items">
              <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\potato.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Organic Potatoes</b><br/>
                   
                   <div class="item-select">
                        Price : 40 Rs/250grams
                   </div>
                   <label>Qty :</label>
                   <select class="item-select">
                      <option>250 grams</option>
                      <option>500 grams</option>
                      <option>750 grams</option>
                      <option>1000 grams</option>                     
                   </select><br/>
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                  
                   <input type="hidden" name="Item_Name" value="Organic Potatoes">
                   <input type="hidden" name="Price" value="40">
                </div>
              </form>
              </div>
            
              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\coriander.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Organic Coriander</b><br/>
                   <div class="item-select">
                        Price : 30 Rs/250grams
                   </div>
                   <label>Qty :</label>
                   <select class="item-select">
                      <option>250 grams</option>
                      <option>500 grams</option>
                      <option>750 grams</option>
                      <option>1000 grams</option>                     
                   </select><br/>
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Organic Coriander">
                   <input type="hidden" name="Price" value="30">
                </div>
              </form>
              </div>

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\tomato.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Organic Tomatoes</b><br/>
                   <div class="item-select">
                        Price : 25 Rs/250grams
                   </div>
                   <label>Qty :</label>
                   <select class="item-select">
                      <option>250 grams</option>
                      <option>500 grams</option>
                      <option>750 grams</option>
                      <option>1000 grams</option>                     
                   </select><br/>
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <?php
                     
                   ?>
                   <input type="hidden" name="Item_Name" value="Organic Tomatoes">
                   <input type="hidden" name="Price" value="25">
                </div>
              </form>
              </div>


              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\onion.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Yellow Onions</b><br/>
                   <div class="item-select">
                        Price : 30 Rs/250grams
                   </div>
                   <label>Qty :</label>
                   <select class="item-select">
                      <option>250 grams</option>
                      <option>500 grams</option>
                      <option>750 grams</option>
                      <option>1000 grams</option>                     
                   </select><br/>
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Yellow Onions">
                   <input type="hidden" name="Price" value="30">
                </div>
              </form>
              </div>
          

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\spinach.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Organic Spinach</b><br/>
                   <div class="item-select">
                        Price : 30 Rs/250grams
                   </div>
                   <label>Qty :</label>
                   <select class="item-select">
                      <option>250 grams</option>
                      <option>500 grams</option>
                      <option>750 grams</option>
                      <option>1000 grams</option>                     
                   </select><br/>
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Organic Spinach">
                   <input type="hidden" name="Price" value="30">
                </div>
              </form>
              </div>

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\carrot.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Organic Carrots</b><br/>
                   <div class="item-select">
                        Price : 25 Rs/250grams
                   </div>
                   <label>Qty :</label>
                   <select class="item-select">
                      <option>250 grams</option>
                      <option>500 grams</option>
                      <option>750 grams</option>
                      <option>1000 grams</option>                     
                   </select><br/>
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Organic Carrots">
                   <input type="hidden" name="Price" value="25">
                </div>
              </form>
</div>


</div>
    <!--Veg Ends Here-->

    <!--Fruits Begins Here-->
<div class="deals-container" id="Fruits">
           <div class="parallax">
               <div class="title">FASHION OUTFITS</div>
            </div>

            <div class="items">
              <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\trending.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>New Arrivals</b><br/>
                   <div class="item-select">
                        Price : 519 Rs
                   </div>
                   
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="New Arrivals">
                   <input type="hidden" name="Price" value="519">
                </div>
              </form>
              </div>

            <div class="items">
              <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\men.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Men's Fashion</b><br/>
                   <div class="item-select">
                        Price : 430 Rs
                   </div>
                   
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Men's Fashion">
                   <input type="hidden" name="Price" value="430">
                </div>
              </form>
              </div>

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\women.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Women's Fashion</b><br/>
                   <div class="item-select">
                        Price : 650 Rs
                   </div>
                   
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Women's Fashion">
                   <input type="hidden" name="Price" value="650">
                </div>
              </form>
              </div>

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\kids.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Kids Fasion</b><br/>
                   <div class="item-select">
                        Price : 455 Rs
                   </div>
                   
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Kids Fashion">
                   <input type="hidden" name="Price" value="455">
                </div>
              </form>
              </div>


                     

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\baby.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Baby's Outfits</b><br/>
                   <div class="item-select">
                        Price : 369 Rs
                   </div>
                   
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Baby's Outfits">
                   <input type="hidden" name="Price" value="369">
                </div>
              </form>
              </div>


              
</div>
</div>
    <!--Fruits Ends Here-->
    
    <!--Meat Begins Here-->
    <div class="deals-container" id="Meat">
           <div class="parallax">
               <div class="title">APPLIANCES</div>
            </div>
            <div class="items">
              <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\washingmach.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Wasing Machine</b><br/>
                   <div class="item-select">
                        Price : 15,480 Rs
                   </div>
                   
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Wasing Machine">
                   <input type="hidden" name="Price" value="15480">
                </div>
              </form>
              </div>

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\fridge.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Refrigirator</b><br/>
                   <div class="item-select">
                        Price : 30,000 Rs
                   </div>
                   
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Refrigirator">
                   <input type="hidden" name="Price" value="30000">
                </div>
              </form>
              </div>

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\oven.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Oven</b><br/>
                   <div class="item-select">
                        Price : 11,890 Rs
                   </div>
                   
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Oven">
                   <input type="hidden" name="Price" value="11890">
                </div>
              </form>
              </div>


              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\tv.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Television</b><br/>
                   <div class="item-select">
                        Price : 35,000 Rs
                   </div>
                  
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Television">
                   <input type="hidden" name="Price" value="35000">
                </div>
              </form>
              </div>

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\laptop.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Laptops</b><br/>
                   <div class="item-select">
                        Price : 59,000 Rs
                   </div>
                   
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Laptops">
                   <input type="hidden" name="Price" value="59000">
                </div>
              </form>
              </div>

              <div class="items">
                <form action="manage_cart.php" method="post">
               <div class="images">
                  <img src="img\ac.jpg" class="item-image-size"/>
                </div>
                <div class="description">
                   <b>Air Conditioner</b><br/>
                   <div class="item-select">
                        Price : 41,980 Rs
                   </div>
                
                   <button class="buynow-btn" name="Add_To_Cart" type="submit">Buy Now</button>
                   <input type="hidden" name="Item_Name" value="Air Conditioner">
                   <input type="hidden" name="Price" value="41980">
                </div>
              </form>
              </div>
</div>
    <!--Meat Ends Here-->
    <!--Home Page End-->

  <!--footer starts here-->
    <div class="parallaxl">
       <div class="footer">
          <div class="quick-links">
            <div>Address</div>
            <p>Sunshine Street<br>Parijat Nagar, Nashik,<br> Maharashtra<br>422100</p>
          </div>
           <div class="quick-links">
            <h3>Phone</h3>
              <p>502-425-6025</p>
          </div>
           <div class="quick-links">
            
            <ul>
              <h3>Email</h3>
              <p>shoponline@gmail.com</p>
            </ul>
          </div>
        </div>
      </div>
      
  <!--footer  ends here-->
</body>
</html>

</BODY>
</HTML>