<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>






    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/dresses/d5.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Fit and Flare White Dress</h5>
                         <p class="card-text">Price : Rs.738</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Fit and Flare White Dress">
                          <input type="hidden" name="Price" value="738">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/dresses/d13.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Skater Black <br>Dress</h5>
                         <p class="card-text">Price : Rs.824</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Skater Black Dress">
                          <input type="hidden" name="Price" value="824">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/dresses/d4.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Ruffled Purple <br>Dress</h5>
                         <p class="card-text">Price : Rs.549</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Ruffled Purple Dress">
                          <input type="hidden" name="Price" value="549">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/dresses/d8.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Fit and Flare <br>Maroon Dress</h5>
                         <p class="card-text">Price : Rs.899</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Fit and Flare Maroon Dress">
                          <input type="hidden" name="Price" value="899">
                    </div>
                </div>
                </form>
    		</div>
</div>
</div> <br><br>

 <div class="container mt-4">
      <div class="row">

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/dresses/d14.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Maxi Brown <br>Dress</h5>
                         <p class="card-text">Price : Rs.799</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Maxi Brown Dress">
                          <input type="hidden" name="Price" value="799">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/dresses/d15.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Bandage Blue <br>Dress</h5>
                         <p class="card-text">Price : Rs.750</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Bandage Blue Dress">
                          <input type="hidden" name="Price" value="750">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/dresses/d10.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title"> Women Skater Black <br>Dress</h5>
                         <p class="card-text">Price : Rs.835</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Skater Black Dress">
                          <input type="hidden" name="Price" value="835">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/dresses/d19.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Shift Maroon <br>Dress</h5>
                         <p class="card-text">Price : Rs.999</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Shift Maroon Dress">
                          <input type="hidden" name="Price" value="999">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div><br><br><br>
</body>
</html>