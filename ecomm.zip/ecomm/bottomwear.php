<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>



    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/bottomwear/b1.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Flared Women Blue Jeans</h5>
                         <p class="card-text">Price : Rs.1050</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Flared Women Blue Jeans">
                          <input type="hidden" name="Price" value="1050">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/bottomwear/b10.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Jogger Fit Women Pink <br>Jeans</h5>
                         <p class="card-text">Price : Rs.860</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Jogger Fit Women Pink Jeans">
                          <input type="hidden" name="Price" value="860">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/bottomwear/b11.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Skinny Women Red Jeans</h5>
                         <p class="card-text">Price : Rs.899</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Skinny Women Red Jeans">
                          <input type="hidden" name="Price" value="899">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/bottomwear/b4.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Skinny Women Blue <br>Jeans</h5>
                         <p class="card-text">Price : Rs.685</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Skinny Women Blue Jeans">
                          <input type="hidden" name="Price" value="685">
                    </div>
                </div>
                </form>
    		</div>
</div>
</div> <br><br>

 <div class="container mt-4">
      <div class="row">

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/bottomwear/b12.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Solid Women Black,Pink Tights</h5>
                         <p class="card-text">Price : Rs.550</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Solid Women Black, Pink Tights">
                          <input type="hidden" name="Price" value="550">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/bottomwear/b19.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Solid A-line Brown Skirt</h5>
                         <p class="card-text">Price : Rs.654</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Solid A-line Brown Skirt">
                          <input type="hidden" name="Price" value="654">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/bottomwear/b18.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title"> Women Solid Regular <br>Maroon Skirt</h5>
                         <p class="card-text">Price : Rs.499</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Solid Regular Maroon Skirt">
                          <input type="hidden" name="Price" value="499">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/bottomwear/b20.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Solid Tulip Black Skirt</h5>
                         <p class="card-text">Price : Rs.530</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Solid Tulip Black Skirt">
                          <input type="hidden" name="Price" value="530">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div><br><br><br>
</body>
</html>