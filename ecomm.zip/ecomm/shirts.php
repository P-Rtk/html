<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>






    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/shirts/s1.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Regular Fit Printed Spread Collar Casual Shirt</h5>
                         <p class="card-text">Price : Rs.440</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Regular Fit Printed Spread Collar Casual Shirt">
                          <input type="hidden" name="Price" value="440">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/shirts/s2.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Regular Cut Away Collar Casual Shirt</h5>
                         <p class="card-text">Price : Rs.685</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Regular Cut Away Collar Casual Shirt">
                          <input type="hidden" name="Price" value="685">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/shirts/s7.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Slim Fit Mandarin Collar Casual Shirt</h5>
                         <p class="card-text">Price : Rs.899</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Slim Fit Mandarin Collar Casual Shirt">
                          <input type="hidden" name="Price" value="899">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/shirts/s9.jpeg" class="card-img-top"><br><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Slim Fit Striped Spread Collar Casual Shirt</h5>
                         <p class="card-text">Price : Rs.478</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Slim Fit Striped Spread Collar Casual Shirt">
                          <input type="hidden" name="Price" value="478">
                    </div>
                </div>
                </form>
    		</div>
</div>
</div> <br><br>

 <div class="container mt-4">
      <div class="row">

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/shirts/s5.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Regular Fit Solid Spread Collar Casual Shirt</h5>
                         <p class="card-text">Price : Rs.733</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Regular Fit Solid Spread Collar Casual Shirt">
                          <input type="hidden" name="Price" value="733">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/shirts/s20.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Regular Fit Printed Casual Shirt</h5>
                         <p class="card-text">Price : Rs.690</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Regular Fit Printed Casual Shirt">
                          <input type="hidden" name="Price" value="690">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/shirts/s3.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Slim Fit Checkered Spread Collar Casual Shirt</h5>
                         <p class="card-text">Price : Rs.599</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Slim Fit Checkered Spread Collar Casual Shirt">
                          <input type="hidden" name="Price" value="599">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/shirts/s18.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Men Slim Fit Striped, Printed Casual Shirt</h5>
                         <p class="card-text">Price : Rs.999</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Men Slim Fit Striped, Printed Casual Shirt">
                          <input type="hidden" name="Price" value="999">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div><br><br><br>
</body>
</html>