<?php 
     session_start();
  $con = mysqli_connect("localhost","root","") or die("unable to connect");
  mysqli_select_db($con,'pblproject');
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/login.css" />
    <title>Sign in and sign up here!!</title>
  </head>
  <body>
    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="sign-in-form" method="post">
            <h2 class="title">Sign in</h2>
            <div class="input-field">
              <i class="fa fa-user"></i>
              <input type="text" placeholder="Username" name="username"/>
            </div>
            <div class="input-field">
              <i class="fa fa-lock"></i>
              <input type="password" placeholder="Password" name="password" required  />
            </div>
            <input type="submit" value="Login" class="btn solid" name="submit_btn" />

            <?php 

                                  if(isset($_POST['submit_btn']))
                                  {
                                    $username = $_POST['username'];
                                    $password = $_POST['password'];

                                    $query="select * from users where Username='$username' AND Password='$password'";

                                    $query_run = mysqli_query($con,$query);

                                    if(mysqli_num_rows($query_run)>0)
                                    {
                                        
                                        $_SESSION['Username']=$username;
                                        header('location:home.php');
                                    }
                                    else
                                    {
                                         echo '<script type="text/javascript"> alert("Invalid Credentials!!!")</script>';
                                    }
                                  }
                                ?>      
            
          </form>
         
          <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="sign-up-form" method="post">
            <h2 class="title">Sign up</h2>
            <div class="input-field">
              <i class="fa fa-user"></i>
              <input type="text" placeholder="Username" name="uname" required />
              
            </div>
            <div class="input-field">
              <i class="fa fa-envelope"></i>
              <input type="email" placeholder="Email" name="emailid" required  />
              
            </div>
            <div class="input-field">
              <i class="fa fa-lock"></i>
              <input type="password" pattern=".{8,}" required title="8 characters minimum" name="pass" placeholder="Password">
            </div>
            <input type="submit" class="btn" value="Sign up" name="signup_btn" />
            
          <?php 

            if(isset($_POST['signup_btn']))
            {
               $username = $_POST['uname'];
               $email = $_POST['emailid'];
               $password = $_POST['pass'];

               $query = "select * from users where Username= '$username'";
               $query_run = mysqli_query($con,$query);

               if(mysqli_num_rows($query_run)>0)
               {
                echo '<script type="text/javascript"> alert("username already exists!! try with another username")</script>';
               }

               else
               {
                $query="insert into users values('','$email','$username','$password')";
                $query_run=mysqli_query($con,$query);

                if($query_run)
                {
                    echo '<script type="text/javascript"> alert("user registered go to login page..")</script>';
                }

                else
                {
                    echo '<script type="text/javascript"> alert("error!!!")</script>';
                }
               }
            }
          
            ?>
            
          </form>
        </div>
      </div>

      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">
            <h3>New here ?</h3>
            <p>
              Create your account to unlock
              more features and services!!!
            </p>
            <button class="btn transparent" id="sign-up-btn">
              Sign up
            </button>
          </div>
          <img src="img/img1.svg" class="image" alt="" />
        </div>
        <div class="panel right-panel">
          <div class="content">
            <h3>One of us ?</h3>
            <p class="one">
             Login to your exisitng account
             and order now!!
            </p>
            <button class="btn transparent" id="sign-in-btn">
              Sign in
            </button>
          </div>
          <img src="img/img2.svg" class="image" alt="" />
        </div>
      </div>
    </div>

    <script src="js/signinandsignup.js"></script>
  </body>
</html>

