<!DOCTYPE html>
<html>
<head>
	<title>Shop Online</title>
	<style type="text/css">
		.img
		{
			text-align: center;
		}
	</style>
</head>
<body><br><br><br><br>
<div class="img">
	<img src="img/last.jpeg" width="800px" height="500px"  border="2px">
</div>
</body>
</html>