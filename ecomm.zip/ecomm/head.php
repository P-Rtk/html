<?php

session_start();

?>


<!DOCTYPE html>
<html>
<head>
    <TITLE>Shop Online</TITLE>
    <style type="text/css">
        .nav{
            text-align: center;
        }
    </style>
    <META NAME="Generator" CONTENT="Editplus">
    <META NAME="Author" CONTENT=" ">
    <META NAME="Keywords" CONTENT=" ">
    <META NAME="Discription" CONTENT=" ">
    <link rel="stylesheet" type="text/css" href="css/headercss.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        <link rel="stylesheet" href="K:\fontawesome\fontawesome-free-5.13.0-web\fontawesome-
    fontawesome-free-5.13.0-web\css\all.min.css">
        <script>
        function stickyMenu() {
            var sticky=document.getElementById('sticky');
            if (window.pageYOFFset > 220) {
                sticky.classList.add('sticky');
            }
            else{
                sticky.classList.remove('sticky');
            }
        }
    window.onscroll=function() {
        stickyMenu();
    }
    </script>
    <link rel="stylesheet" type="text/css" href="top.css">
</head>
<body background="E:\project3\images\new1.jpg" align="center">
    <div class="parallax" style="background-image:url('img/back.jpg')">
        <div class="page-title">Shop Online</div>
    </div>
<nav class="nav" align="center">
    <ul class="menu" align="center">
        <li class="menu_item"><a href="home.php">Home</a></li>
        <li class="menu_item"><a href="aboutus.php">About Us</a>
        <li class="menu_item"><a href="contactus.php">Contact Us</a>
        <li class="menu_item"><a href="categorymain.php">Products</a>
            <ul class="submenu">
                <li class="men_item dropit"> <a href="#">Men</a>
                    <ol class="men thirdlevel">
                        <li><a href="tshirts.php">Tshirt</a></li>
                        <li><a href="#">Shirt</a></li>
                        <li><a href="#">Ethnic Kurtas</a></li>
                        <li><a href="#">Sweatshirts</a></li>
                        <li><a href="jeans.php">Jeans</a></li>
                        
                        </ol>
                    </li>
                <li class="women_item dropit"> <a href="#">Women</a> 
                     <ol class="women thirdlevel">
                        <li><a href="#">Tops</a></li>
                        <li><a href="#">Tshirts</a></li>
                        <li><a href="#">Kurtas</a></li>
                        <li><a href="#">Palazzos</a></li>
                        <li><a href="#">Pants</a></li>
                        <li><a href="#">Sleepwear</a></li>
                        <li><a href="#">Denim</a></li>
                        <li><a href="#">Jeggings</a></li>
                        <li><a href="#">Leggings</a></li>
                        <li><a href="#">Salwars</a></li>
                        <li><a href="#">Skirts</a></li>
                        <li><a href="#">Dresses</a></li>
                        <li><a href="#">Jackets</a></li>
                        <li><a href="#">Shrugs</a></li>
                        <li><a href="#">Sportswear</a></li>
                            
                        
                     </ol>
                     </li>
                <li class="kids_item dropit"> <a href="#">Kids</a>
                    <ol class="kids thirdlevel">
                        <li><a href="#">Girls Tops</a></li>
                        <li><a href="#">Girls Tshirts</a></li>
                        <li><a href="#">Girls Jaclets</a></li>
                        <li><a href="#">Boys Shirts</a></li>
                        <li><a href="#">Boys Tshirts</a></li>
                        <li><a href="#">Boys Jacket</a></li>
                        <li><a href="#">Boys Jeans</a></li>
                        <li><a href="#">Girls Jeans</a></li>
                        <li><a href="#">Leggings</a></li>
                        <li><a href="#">Girls skirts</a></li>
                        <li><a href="#">Girls Frock</a></li>
                        <li><a href="#">Boys Ethnic Wear</a></li>
                        <li><a href="#">Girls Ethnic Wear</a></li>
                        
                            
                        
                     </ol>

                 </li>

                <li class="elect_item dropit"> <a href="#">Electronics</a>
                    <ol class="elect thirdlevel">
                        <li><a href="#">Home Appliances</a></li>
                        <li><a href="#">Kitchen Appliances</a></li>
                        <li><a href="#">Accessories</a></li>
                        <li><a href="#">Grooming Products</a></li>
                         </ol>

                 </li>
                <li class="gro_item dropit"> <a href="#">Grocery</a>
                    <ol class="gro thirdlevel">
                        <li><a href="#">Vegetable</a></li>
                        <li><a href="#">Fruits</a></li>
                        
                     </ol>
                 </li>

                <li class="submenu_item dropit"> <a href="#">Footwear</a>
                    <ol class="foot thirdlevel">
                        <li class="FM_items dropit2"><a href="#">Men</a>
                              <ol class="FM fourthlevel">
                                <li><a href="#">Shoes</a></li>
                                <li><a href="#">Sandles</a></li>
                                <li><a href="#">Slippers</a></li>
                                <li><a href="#">Sneakers</a></li>
                                
                              </ol>
                              </li>
                        <li class="foot_item dropit2"><a href="#">Women</a>
                        <ol class="FW fourthlevel ">
                                <li><a href="#">Shoes</a></li>
                                <li><a href="#">Sandles</a></li>
                                <li><a href="#">Slippers</a></li>
                                <li><a href="#">Sneakers</a></li>
                                <li><a href="#">Flats</a></li>
                                
                              </ol>
                              </li>
                        <li class="Fk_items dropit2"><a href="#">Kids</a>
                        <ol class="FK fourthlevel">
                                <li><a href="#">Shoes</a></li>
                                <li><a href="#">Sandles</a></li>
                                <li><a href="#">Slippers</a></li>
                                <li><a href="#">Sneakers</a></li>
                                <li><a href="#">Flats</a></li>
                                
                              </ol>
                              </li>
                        
                     </ol>
               
                </li>

                <li class="stat_item dropit"> <a href="#">Stationary</a>
                    <ol class="stat thirdlevel">
                        <li><a href="#">Art & Hobby sets</a></li>
                        <li><a href="#">Other school supplies</a></li>
                        </li>
                     </ol>
                <li class="cos_item dropit"> <a href="#">Cosmetics</a>
                    <ol class="cos thirdlevel">
                        <li><a href="#">Beauty Accessories</a></li>
                        <li><a href="#">Personal Care</a></li>
                        </li>
                     </ol>

                 </li>
                </ul>
       

        <?php
               $count=0;
               if(isset($_SESSION['cart']))
               {
                $count=count($_SESSION['cart']);
               }

        ?>

        <a href="mycart.php" class="btn btn-outline-success">My cart( <?php echo $count;  ?>)</a>
      </li>
</nav>
</body>
</html>