<?php

include("header.php");
include("tshirts.php");
include("shirts.php");
include("sweatshirts.php");
include("jeans.php");
include("kurtas.php");

include("tops.php");
include("dresses.php");
include("sarees.php");
include("kurtaset.php");
include("bottomwear.php");
?>

<!--<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>



      <div class="container mt-5">
      	<div  class="row">

        <div class="col-lg-3">
         <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="Men's/t-shirts/t1.jpeg" class="card-img-top" alt="...">
                    <div class="card-body text-center">
                        <h5 class="card-title">tshirt 1</h5>
                        <p class="card-text">Price: Rs.450</p>
                        <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="tshirt 1">
                        <input type="hidden" name="Price" value="450">
                    </div>
            </div>
          </form>
        </div>


        <div class="col-lg-3">
         <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="Men's/t-shirts/t1.jpeg" class="card-img-top" alt="...">
                    <div class="card-body text-center">
                        <h5 class="card-title">tshirt 2</h5>
                        <p class="card-text">Price: Rs.950</p>
                        <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="tshirt 2">
                        <input type="hidden" name="Price" value="950">
                    </div>
            </div>
          </form>
        </div>

        <div class="col-lg-3">
         <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="Men's/t-shirts/t1.jpeg" class="card-img-top" alt="...">
                    <div class="card-body text-center">
                        <h5 class="card-title">tshirt 3</h5>
                        <p class="card-text">Price: Rs.520</p>
                        <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="tshirt 3">
                        <input type="hidden" name="Price" value="520">
                    </div>
            </div>
          </form>
        </div>

        <div class="col-lg-3">
         <form action="manage_cart.php" method="POST">
            <div class="card">
                <img src="Men's/t-shirts/t1.jpeg" class="card-img-top" alt="...">
                    <div class="card-body text-center">
                        <h5 class="card-title">tshirt 4</h5>
                        <p class="card-text">Price: Rs.650</p>
                        <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
                        <input type="hidden" name="Item_Name" value="tshirt 4">
                        <input type="hidden" name="Price" value="650">
                    </div>
            </div>
          </form>
        </div>

      	</div>
      </div>



</body>
</html>-->