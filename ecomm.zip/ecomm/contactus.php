<?php
  include("dbconfig/config.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scaled=1.0">
	<title>Get in touch with us!!</title>
	<link rel="stylesheet" type="text/css" href="css/contactus.css">
</head>

<body>
     <section class="contact">
     	<div class="content">
     		<center><h2>Contact Us</h2>
     		<p>Have any questions? We love to hear!!!<br>
     		Contact Us for any questions or inquiries. We would be happy to answer all your questions. </p></center>
     	</div>

     	<div class="container">
     		<div class="contactInfo">
     			<div class="box">
     				<div class="icon"></i></div>
     				<div class="text">
     					<h3>Address</h3>
     					<p>Sunshine Street<br>Parijat Nagar, Nashik,<br> Maharashtra<br>422100</p>
     				</div>
     			</div>

     			<div class="box">
     				<div class="icon"></i></div>
     				<div class="text">
     					<h3>Phone</h3>
     					<p>502-425-6025</p>
     				</div>
     			</div>

     			<div class="box">
     				<div class="icon"></i></div>
     				<div class="text">
     					<h3>Email</h3>
     					<p>shoponline@gmail.com</p>
     				</div>
     			</div>
     		</div>

            <div class="contactForm">
            	<form action="contactus.php" method="POST">
            		<h2>Send Message</h2>
            		<div class="inputBox">
            			<input type="text" name="fname" required="required">
            			<span>Full Name</span>
            		</div>
            		<div class="inputBox">
            			<input type="text" name="email" required="required">
            			<span>Email</span>
            		</div>
            		<div class="inputBox">
            			<input type="text" name="msg" required="required">
            			<span>Type your Message...</span>
            		</div>
            		<div class="inputBox">
            			<center><button name="submit_btn" style="height: 30px;width: 300px; color: white; background-color: blue;">Send</button></center>
            		</div>
                    <?php
            if(isset($_POST['submit_btn']))
            {
               $name = $_POST['fname'];
               $email = $_POST['email'];
               $message = $_POST['msg'];

              
                $query="insert into contactus values('','$name','$email','$message')";
                $query_run=mysqli_query($con,$query);

                if($query_run)
                {
                    echo "
                    <script>
                    alert('Message Sent!!');
                    window.location.href='home.php';
                    </script>
                    ";
                }

                else
                {
                    echo '<script type="text/javascript"> alert("error!!!")</script>';
                }
               }
            
        ?>

                </form>
            </div>
        </div>

        
     </section>
</body>
</html>