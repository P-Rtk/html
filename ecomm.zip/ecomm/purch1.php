<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/ckeckoutcss.css">
  </head>
  <body>
<div class="login-box">
  <h1>Checkout Form</h1>
  <div class="textbox">
    
    <input type="text" placeholder="Enter Your Name" name="full_name" required>
  </div>

  <div class="textbox">

    <input type="password" placeholder="Email id" name="email" required>
  </div>

  <div class="textbox">

    <input type="number" placeholder="Phone No" name="phone_no" required>
  </div>


  <div class="textbox">

    <input type="text" placeholder="Address" name="address" required>
  </div>
  <div class="textbox">

    <input type="text" placeholder="City" name="city" required>
  </div>

<div class="textbox">
  <input type="text" placeholder="State" name="state" required>
</div>

<div class="textbox">
  <input type="text" placeholder="Zip Code" name="code" required>
</div>


  <input type="button" class="btn" value="Confirm">
</div>
 </form>

 

  </body>
</html>
