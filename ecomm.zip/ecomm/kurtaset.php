<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>



    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/kurtas set/ks1.jpeg" class="card-img-top"><br><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Kurta and Sharara Set Rayon</h5>
                         <p class="card-text">Price : Rs.649</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Kurta and Sharara Set Rayon">
                          <input type="hidden" name="Price" value="649">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/kurtas set/ks9.jpeg" class="card-img-top"><br><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Printed Rayon Flared Kurta  (White)</h5>
                         <p class="card-text">Price : Rs.780</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Printed Rayon Flared Kurta  (White)">
                          <input type="hidden" name="Price" value="780">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/kurtas set/ks13.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Kurta, Pyjama & Dupatta Set Rayon</h5>
                         <p class="card-text">Price : Rs.899</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Kurta, Pyjama & Dupatta Set Rayon">
                          <input type="hidden" name="Price" value="899">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/kurtas set/ks11.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Printed Rayon Anarkali Kurta  (Blue)</h5>
                         <p class="card-text">Price : Rs.729</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Printed Rayon Anarkali Kurta  (Blue)">
                          <input type="hidden" name="Price" value="729">
                    </div>
                </div>
                </form>
    		</div>
</div>
</div> <br><br>

 <div class="container mt-4">
      <div class="row">

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/kurtas set/ks14.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Kurta and Sharara Set Rayon</h5>
                         <p class="card-text">Price : Rs.849</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Kurta and Sharara Set Rayon">
                          <input type="hidden" name="Price" value="849">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/kurtas set/ks7.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Kurta and Palazzo <br>Set Rayon</h5>
                         <p class="card-text">Price : Rs.841</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Kurta and Palazzo Set Rayon">
                          <input type="hidden" name="Price" value="841">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/kurtas set/ks20.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title"> Women Kurta and Pant <br>Set Rayon</h5>
                         <p class="card-text">Price : Rs.645</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Kurta and Pant Set Rayon">
                          <input type="hidden" name="Price" value="645">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/kurtas set/ks4.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Women Printed Rayon Straight Kurta(White, Black)</h5>
                         <p class="card-text">Price : Rs.956</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Women Printed Rayon Straight Kurta(White, Black)">
                          <input type="hidden" name="Price" value="956">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div><br><br><br>
</body>
</html>