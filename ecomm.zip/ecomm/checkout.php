<?php
   require 'dbconfig/config.php';
   session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Details!!</title>
	<link rel="stylesheet" href="css/checkout.css">
</head>
<body>

<div class="wrapper">
  <form method="post" action="checkout.php" >
    <div class="title">
      Please Enter Your Details Here!!!
    </div>
    <div class="form">
       <div class="inputfield">
          <label>First Name</label>
          <input type="text" class="input" name="fname">
       </div>  
        <div class="inputfield">
          <label>Last Name</label>
          <input type="text" class="input" name="lname">
       </div>  
      
        <div class="inputfield">
          <label>Email Address</label>
          <input type="text" class="input" name="email">
       </div> 
      <div class="inputfield">
          <label>Phone Number</label>
          <input type="text" class="input" name="phone_no">
       </div> 
      <div class="inputfield">
          <label>Address</label>
          <textarea class="textarea" name="address"></textarea>
       </div> 
      <div class="inputfield">
          <label>City</label>
          <input type="text" class="input" name="city">
       </div> 
      <div class="inputfield terms">
          <label class="check">
            <input type="checkbox">
            <span class="checkmark"></span>
          </label>
          <p>Agreed to terms and conditions</p>
       </div> 
      <div class="inputfield">
        <input type="submit" value="Place Order" class="btn"b name="place_btn">
      </div>
      <?php

    if(isset($_POST['place_btn']))
            {
               
               $user = $_SESSION['Username'];
               $name = $_POST['fname'];
               $email = $_POST['email'];
               $phone = $_POST['phone_no'];
               $address = $_POST['address'];
               $city = $_POST['city'];
               $_SESSION['addres']=$_POST['address'];
               
               

                $query="insert into cust_info values('','$user','$name','$address','$city','$phone')";
                $query_run=mysqli_query($con,$query);

                if($query_run)
                {
                    echo '<script type="text/javascript"> alert("Order placed successfully!!")
                    window.location.href="confirmorder.php"</script>';
                }

                else
                {
                    echo '<script type="text/javascript"> alert("Unable to palce order!!!")</script>';
                }
               
            }


 ?></form>
    </div>
</div>	
	
</body>
</html>