<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>






    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/t-shirts/t1.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Striped Men Round Neck Blue Tshirt</h5>
                         <p class="card-text">Price : Rs.599</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Striped Men Round Neck Blue Tshirt">
                          <input type="hidden" name="Price" value="599">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/t-shirts/t4.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Striped Men Round Neck Yellow T-Shirt</h5>
                         <p class="card-text">Price : Rs.499</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Striped Men Round Neck Yellow T-Shirt">
                          <input type="hidden" name="Price" value="499">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/t-shirts/t2.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Color Block Men Round Neck Red, Black T-Shirt</h5>
                         <p class="card-text">Price : Rs.650</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Color Block Men Round Neck Red, Black T-Shirt">
                          <input type="hidden" name="Price" value="650">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/t-shirts/t3.jpeg" class="card-img-top"><br><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Solid Men Hooded Neck White,Red T-Shirt</h5>
                         <p class="card-text">Price : Rs.650</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Solid Men Hooded Neck White,Red T-Shirt">
                          <input type="hidden" name="Price" value="650">
                    </div>
                </div>
                </form>
    		</div>
</div>
</div> <br><br>

 <div class="container mt-4">
      <div class="row">

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/t-shirts/t5.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Striped Men Round Neck Pink T-Shirt</h5>
                         <p class="card-text">Price : Rs.530</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Striped Men Round Neck Pink T-Shirt">
                          <input type="hidden" name="Price" value="530">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/t-shirts/t8.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Color Block Men Round Neck Dark Green T-Shirt</h5>
                         <p class="card-text">Price : Rs.690</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Color Block Men Round Neck Dark Green T-Shirt">
                          <input type="hidden" name="Price" value="690">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/t-shirts/t14.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Geometric Print Men Round Neck Blue T-Shirt</h5>
                         <p class="card-text">Price : Rs.780</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Geometric Print Men Round Neck Blue T-Shirt">
                          <input type="hidden" name="Price" value="780">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Men's/t-shirts/t15.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Solid Men Polo Neck Black T-Shirt</h5>
                         <p class="card-text">Price : Rs.580</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Solid Men Polo Neck Black T-Shirt">
                          <input type="hidden" name="Price" value="580">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div>
</body>
</html>