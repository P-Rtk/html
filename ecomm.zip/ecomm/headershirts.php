<?php
session_start();

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Slider</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/categorymaincss.css">

</head>
<body>

<center>
<center>
  <nav class="nav" >
  <ul class="menu">
    <li class="menu_item"><a href="home.php">Home</a></li>
    <li class="menu_item"><a href="aboutus.php">About</a></li>
    <li class="menu_item"><a href="contactus.php">Contact</a></li>
    <li class="menu_item"><a href="categorymain.php">Categories</a>
      <ul class="submenu">
        <li class="men_item dropit"> <a href="#">Men's</a>
          <ol class="men thirdlevel">
            <li><a href="index.php">T-shirt</a></li>
            <li><a href="indexshirts.php">Shirts</a></li>
            <li><a href="Men's/kurtas/kurtas.php">Ethenic Kurtas</a></li>
            <li><a href="Men's/sweatshirts/sweatshirts.php">Sweatshirts</a></li>
            <li><a href="Men's/jeans/jeans.php">Jeans</a></li>
            </ol>
          </li>

        <li class="women_item dropit"> <a href="#">Women's</a> 
             <ol class="women thirdlevel">
              <li><a href="#">Tops</a></li>
              <li><a href="#">Kurtas Sets</a></li>
              <li><a href="#">Sarees</a></li>
              <li><a href="#">Dresses</a></li>
              <li><a href="#">Bottowear</a></li>
             </ol>
             </li>

        <li class="kids_item dropit"> <a href="#">Kids</a>
          <ol class="kids thirdlevel">
              <li><a href="#">Girls Tops</a></li>
              <li><a href="#">Girls Tshirts</a></li>
              <li><a href="#">Girls Jaclets</a></li>
              <li><a href="#">Boys Shirts</a></li>
              <li><a href="#">Boys Tshirts</a></li>
            <li><a href="#">Boys Jacket</a></li>
              <li><a href="#">Boys Jeans</a></li>
              <li><a href="#">Girls Jeans</a></li>
              <li><a href="#">Leggings</a></li>
              <li><a href="#">Girls skirts</a></li>
              <li><a href="#">Girls Frock</a></li>
              <li><a href="#">Boys Ethnic Wear</a></li>
              <li><a href="#">Girls Ethnic Wear</a></li>
              
                
              
             </ol>

         </li>

        <li class="elect_item dropit"> <a href="#">Electronics</a>
          <ol class="elect thirdlevel">
              <li><a href="#">Home Appliances</a></li>
              <li><a href="#">Kitchen Appliances</a></li>
              <li><a href="#">Accessories</a></li>
              <li><a href="#">Grooming Products</a></li>
               </ol>

         </li>
        <li class="gro_item dropit"> <a href="#">Grocery</a>
          <ol class="gro thirdlevel">
              <li><a href="#">Vegetable</a></li>
              <li><a href="#">Fruits</a></li>
              
             </ol>
         </li>

        <li class="submenu_item dropit"> <a href="#">Footwear</a>
                    <ol class="foot thirdlevel">
              <li class="FM_items dropit2"><a href="#">Men</a>
                    <ol class="FM fourthlevel">
                      <li><a href="#">Shoes</a></li>
                      <li><a href="#">Sandles</a></li>
                      <li><a href="#">Slippers</a></li>
                      <li><a href="#">Sneakers</a></li>
                      
                    </ol>
                    </li>
              <li class="foot_item dropit2"><a href="#">Women</a>
              <ol class="FW fourthlevel ">
                      <li><a href="#">Shoes</a></li>
                      <li><a href="#">Sandles</a></li>
                      <li><a href="#">Slippers</a></li>
                      <li><a href="#">Sneakers</a></li>
                      <li><a href="#">Flats</a></li>
                      
                    </ol>
                    </li>
              <li class="Fk_items dropit2"><a href="#">Kids</a>
              <ol class="FK fourthlevel">
                      <li><a href="#">Shoes</a></li>
                      <li><a href="#">Sandles</a></li>
                      <li><a href="#">Slippers</a></li>
                      <li><a href="#">Sneakers</a></li>
                      <li><a href="#">Flats</a></li>
                      
                    </ol>
                    </li>
              
             </ol>
               
        </li>

        <li class="stat_item dropit"> <a href="#">Stationary</a>
          <ol class="stat thirdlevel">
              <li><a href="#">Art & Hobby sets</a></li>
              <li><a href="#">Other school supplies</a></li>
              </li>
             </ol>
        <li class="cos_item dropit"> <a href="#">Cosmetics</a>
          <ol class="cos thirdlevel">
              <li><a href="#">Beauty Accessories</a></li>
              <li><a href="#">Personal Care</a></li>
              </li>
             </ol>

         </li>
        </ul>
    </li>
    
    <?php 
              
              $count=0;
              if(isset($_SESSION['cart']))
              {
                $count=count($_SESSION['cart']);
              }

            ?>
    <li class="menu_item"><a href="mycartshirts.php">My cart(<?php echo $count;  ?>)</a></li>

     <div class="search-box">
          <form>
            <input type="text" placeholder="Search..." name="search" class="search-input"/>
              <button type="submit"><i class="fa fa-search"></i></button>
          </form>
        </div>
    </div>

  </ul>
</nav>
</li>

</center>
</body>
</html>