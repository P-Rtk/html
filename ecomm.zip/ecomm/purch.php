
<?php
 
  require 'dbconfig/config.php';
  session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/ckeckoutcss.css">
  </head>
  <body>
    <form action="purch.php" method="post">
<div class="login-box">
  <h1>Checkout Form</h1>

  <div class="textbox">
    
    <input type="text" placeholder="Enter Your Name" name="fullname" required>
  </div>

  <div class="textbox">

    <input type="text" placeholder="Email id" name="email" required>
  </div>

  <div class="textbox">

    <input type="text" placeholder="Phone No" name="phone_no" required>
  </div>


  <div class="textbox">

    <input type="text" placeholder="Address" name="address" required>
  </div>
  <div class="textbox">

    <input type="text" placeholder="City" name="city" required>
  </div>

<div class="textbox">
  <input type="text" placeholder="State" name="state" required>
</div>

<div class="textbox">
  <input type="text" placeholder="Zip Code" name="code" required>
</div>
 <div>
  <button class="btn" name="place_btn">Place Order</button>
  <!-- <input type="button" class="btn" value="Place Order" name="place_btn"> -->
</div>

 <?php

    if(isset($_POST['place_btn']))
            {
               
               $user = $_SESSION['Username'];
               $name = $_POST['fullname'];
               $email = $_POST['email'];
               $phone = $_POST['phone_no'];
               $address = $_POST['address'];
               $city = $_POST['city'];
               $state = $_POST['state'];
               $code = $_POST['code'];
               

                $query="insert into cust_info values('','$user','$name','$address','$city','$phone')";
                $query_run=mysqli_query($con,$query);

                if($query_run)
                {
                    echo '<script type="text/javascript"> alert("Order placed successfully!!")
                    window.location.href="confirmorder.php"</script>';
                }

                else
                {
                    echo '<script type="text/javascript"> alert("Unable to palce order!!!")</script>';
                }
               
            }


 ?>
 </form>



  </body>
</html>
