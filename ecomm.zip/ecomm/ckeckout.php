<?php
   session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="styles1.css">
  </head>
  <body>
<div class="login-box">
  <h1>Checkout Form</h1>
  <div class="textbox">
    
    <input type="text" placeholder="Enter Your Name">
  </div>

  <div class="textbox">

    <input type="password" placeholder="Email id">
  </div>

  <div class="textbox">

    <input type="text" placeholder="Address">
  </div>
  <div class="textbox">

    <input type="text" placeholder="City">
  </div>

<div class="textbox">
  <input type="text" placeholder="State">
</div>

<div class="textbox">
  <input type="text" placeholder="Zip Code">
</div>

  <input type="button" class="btn" value="Confirm">
</div>
 
  </body>
</html>
