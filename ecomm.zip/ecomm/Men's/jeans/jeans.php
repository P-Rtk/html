<!DOCTYPE html> 
<html>
<head>
  <title>fashion</title>
  <link rel="stylesheet" type="text/css" href="jeanscss.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css"></style>
</head>
<body>
  
  <div class="related">
    <h1>Jeans</h1>
    <div class="row">
      <div class="column">
        <div class="items" id="productt3">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
           <a href="j1detail.php">
            <img src="j1.jpeg" ></a>
          <div class="details">
            <h3>Urbano Fashion</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
            </div>
             <h4>Slim Men Grey Jeans<br>
             ₹.607 <strike>₹.1,699</strike> (64%) off
           </h4>

</div>
</div>
</div>


      <div class="column">
        <div class="items" id="productt4">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j2detail.php">
          <img src="j2.jpeg">
          </a>
          <div class="details">
            <h3>Lzard</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Regular Men Blue Jeans<br>
            ₹.584 <strike>₹.2,299</strike> (74%) off
           </h4>
          </div>
        </div>
      </div>

<div class="column">
        <div class="items" id="productt5">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j3detail.php">
          <img src="j3.jpeg">
          </a>
          <div class="details">
            <h3>HIGHLANDER</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men Black Jeans<br>
            ₹.519 <strike>₹.1,299</strike> (60%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt6">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j4detail.php">
          <img src="j4.jpeg">
           </a> 
          <div class="details">
            <h3>HIGHLANDER</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Super Skinny White Jeans<br>
            ₹.554 <strike>₹.1,499</strike> (63%) off
           </h4>
          </div>
        </div>
      </div>

       <div class="column">
        <div class="items" id="productt7">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j5detail.php">
          <img src="j5.jpeg">
        </a>
          <div class="details">
            <h3>METRONAUT</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Dark Blue Jeans<br>
             ₹.424 <strike>₹.1.699</strike> (75%) off
           </h4>
          </div>
        </div>
      </div>

       <div class="column">
        <div class="items" id="productt8">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j6detail.php">
          <img src="j6.jpeg">
        </a>
          <div class="details">
            <h3>Lzard</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men Blue Jeans<br>
            ₹.584 <strike>₹.2,299 </strike> (74%) off
           </h4>
          </div>
        </div>
      </div>
       
        <div class="column">
        <div class="items" id="productt9">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j7detail.php">
          <img src="j7.jpeg">
        </a>
          <div class="details">
            <h3>RASSO</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
            </div>
            <h4>Regular Men Grey Jeans<br>
             ₹.499 <strike>₹.2,299</strike> (78%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt10">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j8detail.php">
          <img src="j8.jpeg">
        </a>
          <div class="details">
            <h3>Flying Machine</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men Grey Jeans<br>
            ₹.779 <strike>₹.2,299</strike> (66%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt11">
          <div class="heart" >
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j9detail.php">
          <img src="j9.jpeg">
        </a>
          <div class="details">
            <h3>Urbano Fashion</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men Black Jeans<br>
             ₹.529 <strike>₹.1,499</strike> (64%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt12">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j10detail.php">
          <img src="j10.jpeg">
        </a>
          <div class="details">
            <h3>Urbano Fashion</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men Brown Jeans<br>
             ₹.639 <strike>₹.1,599</strike> (60%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt13">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j11detail.php">
          <img src="j11.jpeg">
        </a>
          <div class="details">
            <h3>Snaave Fit</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men Grey Jeans<br>
             ₹.786 <strike>₹.3,000</strike> (73%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt14">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j12detail.php">
          <img src="j12.jpeg">
        </a>
          <div class="details">
            <h3>Aarzu Style</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
            </div>
            <h4>Slim Men Blue Jeans<br>
            ₹.619 <strike>₹.1,599</strike> (61%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt15">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j13detail.php">
          <img src="j13.jpeg">
        </a>
          <div class="details">
            <h3>KILLER</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Jogger Fit Men Brown Jeans<br>
             ₹.899 <strike>₹.2,699</strike> (66%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt15">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j14detail.php">
          <img src="j14.jpeg">
        </a>
          <div class="details">
            <h3>HIGHLANDER</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Tapered Fit Men Light Blue Jeans<br>
             ₹.599 <strike>₹.1,499</strike> (60%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt16">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j15detail.php">
          <img src="j15.jpeg">
        </a>
          <div class="details">
            <h3>Urbano Fashion</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men White Jeans<br>
             ₹.785 <strike>₹.1,899</strike> (58%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j16detail.php">
          <img src="j16.jpeg">
        </a>
          <div class="details">
            <h3>Campus Sutra</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men Blue Jeans<br>
             ₹.768 <strike>₹.1,899</strike> (59%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j17detail.php">
          <img src="j17.jpeg">
        </a>
          <div class="details">
            <h3>Clothentic</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Multicolor Jeans (Pack of 2)<br>
             ₹.1,199 <strike>₹.1,999</strike> (40%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j18detail.php">
          <img src="j18.jpeg">
        </a>
          <div class="details">
            <h3>Urbano Fashion</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men Brown Jeans<br>
             ₹.588 <strike>₹.1,599</strike> (63%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j19detail.php">
          <img src="j19.jpeg">
        </a>
          <div class="details">
            <h3>Urbano Fashion</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Slim Men Brown Jeans<br>
             ₹.588 <strike>₹.1,599</strike> (63%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="j20detail.php">
          <img src="j20.jpeg">
        </a>
          <div class="details">
            <h3>Clothentic</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Regular Dark Blue Jeans<br>
             ₹.669 <strike>₹.999</strike> (33%) off
           </h4>
          </div>
        </div>
      </div>
      <br><br><br>

  
    </div>
  </div>
</body>
</html>