<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="detailcss.css">
</head>
<body>

	<main class="container">

      <!-- Left Column / Headphones Image -->
      <br><br>
      <div class="left-column">
        <img data-image="red" class="active" src="j16.jpeg" alt="">
      </div>


      <!-- Right Column -->
      <div class="right-column">

        <!-- Product Description -->
        <div class="product-description">
          <span>Jeans</span>
          <h1>Campus Sutra</h1>
          <h2>Slim Men Blue Jeans</h2>
          <p>
          <h4>Product Details : </h4>
          <h4>Features :</h4>
             <p>
              Suitable For : Western Wear<br>
              Pack Of : 1<br>
              Fabric : Dennim<br>
              Pattern : Solid<br>
              Closure : Zipper & Buttoned<br>
              Streatchable : Yes<br>
              Faded : Light Fade<br>
              Color : Blue<br>
              Fabric Care : Gentle Machine wash<br>
          	</p>
          
          <h4>Check Delivery & Services</h4>
          <input type="Number" name="pincode" class="pincode" placeholder="Enter Your Pincode . . .                                         
                          Check">
          <p>
          	Free Delivery on order Above Rs.799<br>
          	Pay on delivery might be available<br>
          	Easy 30 days returns & exchange<br>
          	Try & Buy might be available 
          </p>
        </div>

        <!-- Product Configuration -->
        <div class="product-configuration">

          <!-- Product quantity -->
        <div class="quan">
        <p >Quantity : <input type="text" value="1"></p>
     	</div>

          <!-- Size Configuration -->
          <div class="cable-config">
            <span class="size">Size :</span>
            <br>

            <div class="size-choose">
              <button>28</button>
              <button>30</button>
              <button>32</button>
              <button>34</button>
              <button>36</button>
              <button>38</button>
              <button>40</button>
            </div>
          </div>
       

        <!-- Product Pricing -->
        <div class="product-price">
          <span>₹.768 <strike>₹.1,899</strike> (59%) off</span>
          
        </div><br>
        <div class="product-price">
        	<a href="#" class="btn">+ Wishlist</a>&nbsp
        	<a href="#" class="cart-btn">Add to cart</a>&nbsp
          <a href="#" class="buy-btn">Buy Now</a>
        </div>
      </div>
    </main>


</body>
</html>