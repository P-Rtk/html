<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="detailcss.css">
</head>
<body>

	<main class="container">

      <!-- Left Column / Headphones Image -->
      <br><br>
      <div class="left-column">
        <img data-image="red" class="active" src="k15.jpeg" alt="">
      </div>


      <!-- Right Column -->
      <div class="right-column">

        <!-- Product Description -->
        <div class="product-description">
          <span>Kurta's</span>
          <h1>Royal Garments</h1>
          <h2>Men Kurta, Ethnic Jacket and Pyjama Set Poly Silk</h2>
          <p>
          <h4>Product Details : </h4>
          <h4>Features :</h4>
             <p>
              Fabric : Poly Silk<br>
              Type : Kurta, Ethnic Jacket and Pyjama Set<br>
              Top type : Kurta With Jacket<br>
              Bottom type : Churidar<br>
              Pattern : Self Design<br>
              Color : Multicolor<br>
              Fabric care :Wash Care: First Wash Dry-clean recommended. Hand Wash with a mild detergent thereafter<br>

          	</p>
          
          <h4>Check Delivery & Services</h4>
          <input type="Number" name="pincode" class="pincode" placeholder="Enter Your Pincode . . .                                         
                          Check">
          <p>
          	Free Delivery on order Above Rs.799<br>
          	Pay on delivery might be available<br>
          	Easy 30 days returns & exchange<br>
          	Try & Buy might be available 
          </p>
        </div>

        <!-- Product Configuration -->
        <div class="product-configuration">

          <!-- Product quantity -->
        <div class="quan">
        <p >Quantity : <input type="text" value="1"></p>
     	</div>

          <!-- Size Configuration -->
          <div class="cable-config">
            <span class="size">Size :</span>
            <br>

            <div class="size-choose">
              <button>XS</button>
              <button>S</button>
              <button>M</button>
              <button>L</button>
              <button>XL</button>
              <button>XXL</button>

             
            </div>
          </div>
       

        <!-- Product Pricing -->
        <div class="product-price">
          <span>₹.1,999 <strike>₹.5,000</strike> (60%) off</span>
          
        </div><br>
        <div class="product-price">
        	<a href="#" class="btn">+ Wishlist</a>&nbsp
        	<a href="#" class="cart-btn">Add to cart</a>&nbsp
          <a href="#" class="buy-btn">Buy Now</a>
        </div>
      </div>
    </main>


</body>
</html>