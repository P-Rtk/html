<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="detailcss.css">
</head>
<body>

	<main class="container">

      <!-- Left Column / Headphones Image -->
      <br><br>
      <div class="left-column">
        <img data-image="red" class="active" src="k4.jpeg" alt="">
      </div>


      <!-- Right Column -->
      <div class="right-column">

        <!-- Product Description -->
        <div class="product-description">
          <span>Kurta's</span>
          <h1>Pro Ethic</h1>
          <h2>Men Solid Cotton Blend Asymmetric Kurta  (Dark Blue)</h2>
          <p>
          <h4>Product Details : </h4>
          <h4>Features :</h4>
             <p>
              Length Type : Knee length<br>
              Brand Color : Dark Blue<br>
              Occasion : Festive & Party<br>
              Pattern : Solid<br>
              Type : Straight<br>
              Fabric : Cotton blend<br>
              Neck : Mandarin/Chinese Neck<br>
              Sleeve : Full Sleeve<br>
              Color : Dark Blue<br>
              Fabric Care : First wash dry clean thereafter handwash<br>

          	</p>
          
          <h4>Check Delivery & Services</h4>
          <input type="Number" name="pincode" class="pincode" placeholder="Enter Your Pincode . . .                                         
                          Check">
          <p>
          	Free Delivery on order Above Rs.799<br>
          	Pay on delivery might be available<br>
          	Easy 30 days returns & exchange<br>
          	Try & Buy might be available 
          </p>
        </div>

        <!-- Product Configuration -->
        <div class="product-configuration">

          <!-- Product quantity -->
        <div class="quan">
        <p >Quantity : <input type="text" value="1"></p>
     	</div>

          <!-- Size Configuration -->
          <div class="cable-config">
            <span class="size">Size :</span>
            <br>

            <div class="size-choose">
              <button>XS</button>
              <button>S</button>
              <button>M</button>
              <button>L</button>
              <button>XL</button>
              <button>XXL</button>
             
            </div>
          </div>
       

        <!-- Product Pricing -->
        <div class="product-price">
          <span>₹.748 <striek>₹.1,999</striek> (62%) off</span>
          
        </div><br>
        <div class="product-price">
        	<a href="#" class="btn">+ Wishlist</a>&nbsp
        	<a href="#" class="cart-btn">Add to cart</a>&nbsp
          <a href="#" class="buy-btn">Buy Now</a>
        </div>
      </div>
    </main>


</body>
</html>