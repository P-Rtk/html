<!DOCTYPE html> 
<html>
<head>
  <title>fashion</title>
  <link rel="stylesheet" type="text/css" href="kurtascss.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css"></style>
</head>
<body>
  
  <div class="related">
    <h1>Kurta's</h1>
    <div class="row">
      <div class="column">
        <div class="items" id="productt3">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
           <a href="k1detail.php">
            <img src="k1.jpeg" ></a>
          <div class="details">
            <h3>Parallel Times</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
            </div>
             <h4>Men Solid Pure Cotton<br>Straight Kurta  (Red)<br>
             ₹.475 <strike>₹.1,499</strike> (68%) off
           </h4>

</div>
</div>
</div>


      <div class="column">
        <div class="items" id="productt4">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k2detail.php">
          <img src="k2.jpeg">
          </a>
          <div class="details">
            <h3>Bontebok</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Solid Cotton Blend <br>Straight Kurta  (White)<br>
            ₹.529 <strike>₹.2,999 </strike> (82%) off
           </h4>
          </div>
        </div>
      </div>

<div class="column">
        <div class="items" id="productt5">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k3detail.php">
          <img src="k3.jpeg">
          </a>
          <div class="details">
            <h3>Vibhuti</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Solid Cotton Blend <br>Straight Kurta  (Orange)<br>
            ₹.475 <strike>₹.1,649</strike> (71%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt6">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k4detail.php">
          <img src="k4.jpeg">
           </a> 
          <div class="details">
            <h3>Pro Ethic</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Solid Cotton Blend <br>Asymmetric Kurta  (Dark Blue)<br>
            ₹.748 <striek>₹.1,999</striek> (62%) off
           </h4>
          </div>
        </div>
      </div>

       <div class="column">
        <div class="items" id="productt7">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k5detail.php">
          <img src="k5.jpeg">
        </a>
          <div class="details">
            <h3>Vibhuti</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Solid Cotton Blend <br>Straight Kurta  (Light Green)<br>
             ₹.475 <strike>₹.1,649 </strike> (71%) off
           </h4>
          </div>
        </div>
      </div>

       <div class="column">
        <div class="items" id="productt8">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k6detail.php">
          <img src="k6.jpeg">
        </a>
          <div class="details">
            <h3>ABH Lifestyle</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Solid Cotton Blend <br>Straight Kurta  (Yellow)<br>
            ₹.549 <strike>₹.1,999</strike> (72%) off
           </h4>
          </div>
        </div>
      </div>
       
        <div class="column">
        <div class="items" id="productt9">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k7detail.php">
          <img src="k7.jpeg">
        </a>
          <div class="details">
            <h3>ABH Lifestyle</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
            </div>
            <h4>Men Solid Cotton Blend <br>Straight Kurta  (Grey)<br>
             ₹.549 <strike>₹.1,999</strike> (72%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt10">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k8detail.php">
          <img src="k8.jpeg">
        </a>
          <div class="details">
            <h3>Kiaz Fashion</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Colorblock Cotton Rayon<br>Blend Flared Kurta (Multicolor)<br>
            ₹.1,249 <strike>₹.1,399</strike> (10%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt11">
          <div class="heart" >
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k9detail.php">
          <img src="k9.jpeg">
        </a>
          <div class="details">
            <h3>Kunj Creation</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Self Design Lace <br>Cotton Trail Cut Kurta (Blue)<br>
             ₹.989 <strike>₹.1,599</strike> (38%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt12">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k10detail.php">
          <img src="k10.jpeg">
        </a>
          <div class="details">
            <h3>Benstoke</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Solid Silk Blend <br>Straight Kurta  (Black)<br>
             ₹.549 <strike>₹.1,599</strike> (65%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt13">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k11detail.php">
          <img src="k11.jpeg">
        </a>
          <div class="details">
            <h3>SOJANYA</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Ethnic Jacket and <br>Pyjama Set Poly Silk<br>
            ₹.2,199 <strike>₹.7,999</strike> (72%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt14">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k12detail.php">
          <img src="k12.jpeg">
        </a>
          <div class="details">
            <h3>Royal Garments</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
            </div>
            <h4>Men Kurta, Ethnic Jacket <br>and Pyjama Set Poly Silk<br>
            ₹.1,999 <strike>₹.5,000</strike> (60%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt15">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k13detail.php">
          <img src="k13.jpeg">
        </a>
          <div class="details">
            <h3>Royal Garments</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Kurta, Ethnic Jacket <br>and Pyjama Set Poly Silk<br>
             ₹.1,999 <strike>₹.5,000</strike> (60%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt15">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k14detail.php">
          <img src="k14.jpeg">
        </a>
          <div class="details">
            <h3>Royal Garments</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Kurta, Ethnic Jacket <br>and Pyjama Set Poly Silk<br>
             ₹.1,999 <strike>₹.5,000</strike> (60%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt16">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k15detail.php">
          <img src="k15.jpeg">
        </a>
          <div class="details">
            <h3>Royal Garments</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Kurta, Ethnic Jacket <br>and Pyjama Set Poly Silk<br>
             ₹.1,999 <strike>₹.5,000</strike> (60%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k16detail.php">
          <img src="k16.jpeg">
        </a>
          <div class="details">
            <h3>Royal Garments</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Kurta, Ethnic Jacket <br>and Pyjama Set Poly Silk<br>
             ₹.2,999 <strike>₹.5,000</strike> (40%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k17detail.php">
          <img src="k17.jpeg">
        </a>
          <div class="details">
            <h3>Royal Garments</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Kurta, Ethnic Jacket <br>and Pyjama Set Poly Silk<br>
             ₹.3,250 <strike>₹.5,000</strike> (38%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k18detail.php">
          <img src="k18.jpeg">
        </a>
          <div class="details">
            <h3>Royal Garments</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Kurta, Ethnic Jacket <br>and Pyjama Set Poly Silk<br>
             ₹.4,000 <strike>₹.5,000</strike> (28%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k19detail.php">
          <img src="k19.jpeg">
        </a>
          <div class="details">
            <h3>SOJANYA</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Kurta, Ethnic Jacket <br>and Pyjama Set Dupion Silk<br>
             ₹.4,199 <strike>₹.7,999 </strike> (52%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="k20detail.php">
          <img src="k20.jpeg">
        </a>
          <div class="details">
            <h3>SOJANYA</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Ethnic Jacket and <br>Pyjama Set Poly Silk<br>
             ₹.3,199 <strike>₹.7,999 </strike> (62%) off
           </h4>
          </div>
        </div>
      </div>
      <br><br><br>

  
    </div>
  </div>
</body>
</html>