<?php
session_start();

?>



<HTML>
<HEAD>
	<TITLE>Supermarket</TITLE>
	<META NAME="Generator" CONTENT="Editplus">
	<META NAME="Author" CONTENT=" ">
	<META NAME="Keywords" CONTENT=" ">
	<META NAME="Discription" CONTENT=" ">
    <link rel="stylesheet" href="css/homecss.css"/>
        <link rel="stylesheet" href="K:\fontawesome\fontawesome-free-5.13.0-web\fontawesome-
    fontawesome-free-5.13.0-web\css\all.min.css">
        <script>
    	function stickyMenu() {
    		var sticky=document.getElementById('sticky');
    		if (window.pageYOFFset > 220) {
    			sticky.classList.add('sticky');
    		}
    		else{
    			sticky.classList.remove('sticky');
    		}
    	}
    window.onscroll=function() {
    	stickyMenu();
    }
    </script>

</HEAD>
<BODY>
		<div class="parallax" style="background-image:url('img/back.jpg')">
		<div class="page-title">Big Bazar</div>
	</div>
	<div class="menu" id="sticky">
   <ul class="menu-ul">
        	<a href="home.php" class="a-menu"><li>Home</li></a>
            <a href="aboutus.php" class="a-menu"><li>About Us</li></a>
            <a href="contactus.php" class="a-menu"><li>Contact Us</li></a>
            <a href="loginpage.php" class="a-menu"><li>Login</li></a>
            <a href="categorymain.php" class="a-menu"><li>Catergories</li></a>
            <?php 
              
              $count=0;
              if(isset($_SESSION['cart']))
              {
                $count=count($_SESSION['cart']);
              }

            ?>
            <a href="mycartshirts.php" class="a-menu"><li>My Cart (<?php echo $count;  ?>)</li></a>
        </ul>
                <div class="search-box">
        	<form>
        		<input type="text" placeholder="Search..." name="search" class="search-input"/>
        	    <button type="submit"><i class="fa fa-search"></i></button>
        	</form>
        </div>
    </div>
</div>
</body>
</html>