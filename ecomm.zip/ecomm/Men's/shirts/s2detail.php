<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="detailcss.css">
</head>
<body>

	<main class="container">

      <!-- Left Column / Headphones Image -->
      <br><br>
      <div class="left-column">
        <img data-image="red" class="active" src="s2.jpeg" alt="">
      </div>


      <!-- Right Column -->
      <div class="right-column">

        <!-- Product Description -->
        <div class="product-description">
          <span>Shirts</span>
          <h1>BEING REAL</h1>
          <h2>Men Regular Fit Color Block Cut Away Collar Casual Shirt</h2>
          <p>
          <h4>Product Details : </h4>
          <h4>Features :</h4>
             <p>
              Style Code : BR1005-1<br> 
              Fit : Regular <br> 
              Fabric : Pure Cotton <br>
              Sleeves : Short sleeves <br>
              Pack Of : 1  <br>       
              Pattern : Color Block<br>
              Suitable For : Western Wear<br>  
              Collar : Cut Away<br>
              Fabric Care : Hand Wash<br> 
              Color : Multicolor<br>
          	</p>
          
          <h4>Check Delivery & Services</h4>
          <input type="Number" name="pincode" class="pincode" placeholder="Enter Your Pincode . . .                                         
                          Check">
          <p>
          	Free Delivery on order Above Rs.799<br>
          	Pay on delivery might be available<br>
          	Easy 30 days returns & exchange<br>
          	Try & Buy might be available 
          </p>
        </div>

        <!-- Product Configuration -->
        <div class="product-configuration">

          <!-- Product quantity -->
        <div class="quan">
        <p >Quantity : <input type="text" value="1"></p>
     	</div>

          <!-- Size Configuration -->
          <div class="cable-config">
            <span class="size">Size :</span>
            <br>

            <div class="size-choose">
              <button>XXL</button>
              <button>XL</button>
              <button>Large</button>
              <button>Medium</button>
              <button>Small</button>
            </div>
          </div>
       

        <!-- Product Pricing -->
        <div class="product-price">
          <span>₹.460 <strike>₹.1,500</strike> (69%) off </span>
          
        </div><br>
        <div class="product-price">
        	<a href="#" class="btn">+ Wishlist</a>&nbsp
        	<a href="#" class="cart-btn">Add to cart</a>&nbsp
          <a href="#" class="buy-btn">Buy Now</a>
        </div>
      </div>
    </main>


</body>
</html>