<!DOCTYPE html> 
<html>
<head>
  <title>fashion</title>
  <link rel="stylesheet" type="text/css" href="shirtscss.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css"></style>
</head>
<body>
  
  <div class="related">
    <h1>Shirts</h1>
    <div class="row">
      <div class="column">
        <div class="items" id="productt3">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
           <a href="s1detail.php">
            <img src="s1.jpeg" ></a>
          <div class="details">
            <h3>Drashti Villa</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
            </div>
             <h4>Men Regular Fit Printed <br>Spread Collar Casual Shirt<br>
             ₹.440 <strike>₹.999</strike> (55%) off
           </h4>

</div>
</div>
</div>

        


      <div class="column">
        <div class="items" id="productt4">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s2detail.php">
          <img src="s2.jpeg">
          </a>
          <div class="details">
            <h3>BEING REAL</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Regular Cut Away <br>Collar Casual Shirt<br>
             ₹.460 <strike>₹.1,500</strike> (69%) off 
           </h4>
          </div>
        </div>
      </div>

<div class="column">
        <div class="items" id="productt5">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s3detail.php">
          <img src="s3.jpeg">
          </a>
          <div class="details">
            <h3>HIGHLANDER</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Slim Fit Checkered<br> Spread Collar Casual Shirt<br>
            ₹.499<strike>₹.1,249</strike> (60%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt6">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s4detail.php">
          <img src="s4.jpeg">
           </a> 
          <div class="details">
            <h3>VERO LIE</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Regular Fit <br>Striped Casual Shirt<br>
             ₹.568<strike> ₹.1,888 </strike> (69%) off
           </h4>
          </div>
        </div>
      </div>

       <div class="column">
        <div class="items" id="productt7">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s5detail.php">
          <img src="s5.jpeg">
        </a>
          <div class="details">
            <h3>DEELMO</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Regular Fit Solid<br> Spread Collar Casual Shirt<br>
             ₹.733 <strike>₹.1,399</strike> (47%) off
           </h4>
          </div>
        </div>
      </div>

       <div class="column">
        <div class="items" id="productt8">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s6detail.php">
          <img src="s6.jpeg">
        </a>
          <div class="details">
            <h3>Dennis Lingo</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Slim Fit Solid<br> Spread Collar Casual Shirt<br>
            ₹.749 <strike> ₹.2,499</strike> (70%) off
           </h4>
          </div>
        </div>
      </div>
       
        <div class="column">
        <div class="items" id="productt9">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s7detail.php">
          <img src="s7.jpeg">
        </a>
          <div class="details">
            <h3>Dennis Lingo</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
            </div>
            <h4>Men Slim Fit Mandarin <br>Collar Casual Shirt<br>
             ₹.559<strike> ₹.1,849</strike> (69%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt10">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s8detail.php">
          <img src="s8.jpeg">
        </a>
          <div class="details">
            <h3>DEELMO</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Regular Fit Solid<br> Club Collar Casual Shirt<br>
             ₹.663 <strike>₹.1,399</strike> (52%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt11">
          <div class="heart" >
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s9detail.php">
          <img src="s9.jpeg">
        </a>
          <div class="details">
            <h3>Flying Machine</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Slim Fit Striped <br>Spread Collar Casual Shirt<br>
             ₹.684 <strike>₹.1,799</strike> (61%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt12">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s10detail.php">
          <img src="s10.jpeg">
        </a>
          <div class="details">
            <h3>Mialo Fashion</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Regular Fit Printed<br> Spread Collar Casual Shirt<br>
             ₹.499<strike>₹.1,300</strike> (61%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt13">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s11detail.php">
          <img src="s11.jpeg">
        </a>
          <div class="details">
            <h3>QLonz Store</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Regular Fit Solid<br> Mandarin Collar Casual Shirt<br>
             ₹.689<strike>₹.1,999</strike> (65%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt14">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s12detail.php">
          <img src="s12.jpeg">
        </a>
          <div class="details">
            <h3>Craft Heaven</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
            </div>
            <h4>Men Regular Fit Collar<br>Formal Shirt (Pack of 3)<br>
             ₹.999 <strike>₹.2,497</strike> (59%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt15">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s13detail.php">
          <img src="s13.jpeg">
        </a>
          <div class="details">
            <h3>5TH ANFOLD</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Slim Fit Solid<br> Formal Shirt<br>
             ₹.509 <strike>₹.1,299</strike> (57%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt15">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s14detail.php">
          <img src="s14.jpeg">
        </a>
          <div class="details">
            <h3>English Navy</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Slim Fit Solid<br> Spread Collar Formal Shirt<br>
             ₹.599<strike>₹.999</strike> (44%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt16">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s15detail.php">
          <img src="s15.jpeg">
        </a>
          <div class="details">
            <h3>BEON</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Slim Fit Printed<br>Casual Shirt<br>
             ₹.529<strike>₹.1,999</strike> (73%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s16detail.php">
          <img src="s16.jpeg">
        </a>
          <div class="details">
            <h3>Surhi</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Regular Fit <br>Printed Casual Shirt<br>
             ₹.424 <strike>₹.2,199</strike> (80%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s17detail.php">
          <img src="s17.jpeg">
        </a>
          <div class="details">
            <h3>Kidsor</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Regular Fit <br>Printed Casual Shirt<br>
             ₹.474 <strike>₹.1,399</strike> (66%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s18detail.php">
          <img src="s18.jpeg">
        </a>
          <div class="details">
            <h3>U turn</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Slim Fit Striped,<br> Printed Casual Shirt<br>
             ₹.450 <strike>₹.1,899</strike> (76%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s19detail.php">
          <img src="s19.jpeg">
        </a>
          <div class="details">
            <h3>INDICLUB</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Slim Fit Printed<br>Casual Shirt<br>
             ₹.499 <strike>₹.1,499 </strike> (66%) off
           </h4>
          </div>
        </div>
      </div>

      <div class="column">
        <div class="items" id="productt17">
          <div class="heart">
            <i class="fa fa-heart-o" arial-hidden="true"></i>
          </div>
          <a href="s20detail.php">
          <img src="s20.jpeg">
        </a>
          <div class="details">
            <h3>CNDCREATION</h3>
            <div class="rating">
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star"></i>
              <i class="fa fa-star-half-o"></i>
              <i class="fa fa-star-o"></i>
            </div>
            <h4>Men Regular Fit<br> Printed Casual Shirt<br>
             ₹.549 <strike>₹.2,099</strike> (73%) off
           </h4>
          </div>
        </div>
      </div>
      <br><br><br>

  
    </div>
  </div>
</body>
</html>