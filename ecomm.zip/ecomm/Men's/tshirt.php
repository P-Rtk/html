<?php include("header.php"); 



?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>T-shirts</title>
</head>
<body>




    <div class="container mt-3">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="t1.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Striped Men Round Neck<br> Blue T-Shirt<br></h5>
                         <p class="card-text">Price : Rs.599</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Striped Men Round Neck Blue T-Shirt">
                          <input type="hidden" name="Price" value="599">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="t4.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Striped Men Round Neck<br>Yellow T-Shirt<br></h5>
                         <p class="card-text">Price : Rs.499</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Striped Men Round Neck Yellow T-Shirt">
                          <input type="hidden" name="Price" value="499">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="t3.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Solid Men Hooded Neck White,<br> Red T-Shirt<br></h5>
                         <p class="card-text">Price : Rs.650</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Solid Men Hooded Neck White,Red T-Shirt">
                          <input type="hidden" name="Price" value="650">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="t2.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Color Block Men Round Neck<br>Red, Black T-Shirt<br></h5>
                         <p class="card-text">Price : Rs.650</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Color Block Men Round Neck Red, Black T-Shirt">
                          <input type="hidden" name="Price" value="650">
                    </div>
                </div>
                </form>
    		</div>

    	</div>
    </div>
</body>
</html>