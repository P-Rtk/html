<?php include("header.php"); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<title>Index</title>
</head>
<body>






    <div class="container mt-4">
    	<div class="row">
    		<div class="col-lg-3">
             <form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/sarees/s1.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Printed Mysore Art Silk <br>Saree (Blue, Red)</h5>
                         <p class="card-text">Price : Rs.899</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Printed Mysore Art Silk Saree (Blue, Red)">
                          <input type="hidden" name="Price" value="899">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/sarees/s9.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Self Design, Solid, Georgette Saree  (Red)</h5>
                         <p class="card-text">Price : Rs.1080</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Self Design, Solid, Georgette Saree  (Red)">
                          <input type="hidden" name="Price" value="1080">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/sarees/s3.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Embroidered Bollywood Silk <br>Blend, Vichitra Saree</h5>
                         <p class="card-text">Price : Rs.1765</p>
                          <button type="submit" name="Add_To_Cart" class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Embroidered Bollywood Silk Blend, Vichitra Saree">
                          <input type="hidden" name="Price" value="1765">
                    </div>
                </div>
                </form>
    		</div>

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/sarees/s13.jpeg" class="card-img-top"><br>
                     <div class="card-body text-center">
                      <h5 class="card-title">Woven,Embellished,Self Design Banarasi Silk Saree</h5>
                         <p class="card-text">Price : Rs.799</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Woven,Embellished,Self Design Banarasi Silk Saree">
                          <input type="hidden" name="Price" value="799">
                    </div>
                </div>
                </form>
    		</div>
</div>
</div> <br><br>

 <div class="container mt-4">
      <div class="row">

    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/sarees/s5.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Woven Kanjivaram Art Silk, <br>Jacquard Saree (Dark Green)</h5>
                         <p class="card-text">Price : Rs.1250</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Woven Kanjivaram Art Silk, Jacquard Saree (Dark Green)">
                          <input type="hidden" name="Price" value="1250">
                    </div>
                </div>
                </form>
    		</div>



    		<div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/sarees/s14.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Woven Banarasi Jacquard <br>Saree  (Magenta)</h5>
                         <p class="card-text">Price : Rs.1335</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Woven Banarasi Jacquard Saree  (Magenta)">
                          <input type="hidden" name="Price" value="1335">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/sarees/s7.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title"> Embroidered Banarasi Cotton Silk Saree  (Blue)</h5>
                         <p class="card-text">Price : Rs.1049</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Embroidered Banarasi Cotton Silk Saree  (Blue)">
                          <input type="hidden" name="Price" value="1049">
                    </div>
                </div>
                </form>
    		</div>


            <div class="col-lg-3">
    			<form action="manage_cart.php" method="post">
    			<div class="card">
                    <img src="Women's/sarees/s15.jpeg" class="card-img-top">
                     <div class="card-body text-center">
                      <h5 class="card-title">Woven Kanjivaram Silk Blend <br>Saree  (Red, Mustard)</h5>
                         <p class="card-text">Price : Rs.1500</p>
                          <button type="submit" name="Add_To_Cart"class="btn btn-info">add to cart</button>
                          <input type="hidden" name="Item_Name" value="Woven Kanjivaram Silk Blend Saree  (Red, Mustard)">
                          <input type="hidden" name="Price" value="1500">
                    </div>
                </div>
                </form>
    		</div>


    	</div>
    </div><br><br><br>
</body>
</html>