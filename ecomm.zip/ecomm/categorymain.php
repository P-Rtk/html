<?php
 
 include("header.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Products</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/categorymaincss.css">

</head>
<body>

<center>

       
    <!--Home Page Begins-->
    
    <!--Deal Begins Here-->
       <!-- <div class="deals-container" id="deals" >
          <div class="parallax">
            <div class="title" style="background-image:url('img/back.jpg')">DEALS</div>
          </div>-->
          <div class="deal">
            Save 20% on min-purchase of $149 on vegetable<br/>
            <button class="coupon-btn">Add Coupon</button>
          </div>
          <div class="deal">
            Save 10% on min-purchase of $179 on shoes<br/>
            <button class="coupon-btn">Add Coupon</button>
          </div>
          <div class="deal">
            Save 15% on min-purchase of $199 on Fasion outfits<br/>
            <button class="coupon-btn">Add Coupon</button>
          </div>

        </div>
    <!--Deal Ends Here-->


<br>


 <section class="home">
  <div id="carousel" class="carousel slide" data-ride="carousel">
  <div class="carousel-controls">
    <ol class="carousel-indicators">
      <li data-target="#carousel" data-slide-to="0" class="active" style="background-image:url('img/slide-1.jpg')"></li>
      <li data-target="#carousel" data-slide-to="1" style="background-image:url('img/slide-2.jpeg')"></li>
      <li data-target="#carousel" data-slide-to="2" style="background-image:url('img/slide-3.jpg')"></li>
      
    </ol>
    <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
     <img src="img/left-arrow.svg" alt="Prev"> 
  </a>
  <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
    <img src="img/right-arrow.svg" alt="Next">
  </a>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active" style="background-image:url('img/slide-1.jpg')">

      <div class="container">
         <h2>FASHIONISTA</h2>

         <p >GET UPTO 60% OFF</p>
      </div>
    </div>
    <div class="carousel-item" style="background-image:url('img/slide-2.jpeg')">
      <div class="container">

         <h2>Capturing The World!!</h2>
         <p>Discover our deals of the day on your FAVS....</p>
      </div>
    </div>
    <div class="carousel-item" style="background-image:url('img/slide-3.jpg')">
      <div class="container">
        
         <h2><b><i>KIDOO</i></b></h2>
         <p>All Below 999/-</p>
      </div>
    </div>
  </div>
</div><br><br><br><br>
</section>



<script src="js/bootstrap.bundle.min.js"></script>

</center>
</body>
</html>

